#!/bin/bash
cd $(dirname $0)
java -Xmx1024M -jar vanted.jar